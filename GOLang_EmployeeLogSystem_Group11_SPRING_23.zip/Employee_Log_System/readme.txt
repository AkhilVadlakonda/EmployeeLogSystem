Employee Management System

The Employee Management System is a web-based application that allows companies to manage their employees' information, such as personal details, work schedules The application is built using Go for the backend, HTML and Bootstrap for the frontend, and PostgreSQL for the database.

Installation:

1. To install the Employee Management System, follow these steps:

2. Install Go and PostgreSQL on your machine if you haven't already.

3. Intsall required GO packages - GIN, gorilla.

4. Create a database and provide connection details in db.go  

Download the zip file and open the folder in Visual code studio and

Start the application by running the following command:
go run main.go

Open your web browser and go to http://localhost:8082 to access the application.

Usage:

The Employee Management System provides the following functionalities:

Add new employees
Edit existing employee details
Delete employees
Edit existing user details
View a list of all employees
Attendance status



