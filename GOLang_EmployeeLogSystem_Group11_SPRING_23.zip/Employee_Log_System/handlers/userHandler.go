package handlers

import (
	"math/rand"
	"net/http"
	"strconv"

	"Employee-Log-System/models"

	"github.com/gin-gonic/gin"
)

func (h handler) AllUser(c *gin.Context) {
	var re []models.User
	h.DB.Find(&re)
	c.IndentedJSON(http.StatusOK, re)
}

func (h handler) AddUser(c *gin.Context) {
	// Parse the user details from the request body
	var user models.User
	err := c.BindJSON(&user)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{
			"error": err.Error(),
		})
		return
	}

	// Validate the user details
	if user.UserName == "" || user.Password == "" {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{
			"error": "Username and password are required",
		})
		return
	}

	// Generate a random session ID
	sessionID := strconv.FormatInt(rand.Int63(), 16)

	// Add the session ID to the user object
	user.SessionID = sessionID

	// Add the user to the database
	err = h.DB.Create(&user).Error
	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to create user",
		})
		return
	}

	// Return a success message
	c.JSON(http.StatusOK, gin.H{"message": "User created successfully"})
}

func (h handler) UpdateUser(c *gin.Context) {
	id := c.Param("id")
	var user models.User
	if err := h.DB.Where("id = ?", id).First(&user).Error; err != nil {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}
	err := c.BindJSON(&user)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{
			"error": err.Error(),
		})
		return
	}
	h.DB.Save(&user)
	c.JSON(http.StatusOK, &user)
}

func (h handler) DeleteUser(c *gin.Context) {
	id := c.Param("id")
	var user models.User

	err := h.DB.Where("id = ?", id).First(&user).Error

	if err != nil {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}

	h.DB.Delete(&user)
	c.JSON(http.StatusOK, gin.H{
		"status": "Deleted Successfully",
	})
}
