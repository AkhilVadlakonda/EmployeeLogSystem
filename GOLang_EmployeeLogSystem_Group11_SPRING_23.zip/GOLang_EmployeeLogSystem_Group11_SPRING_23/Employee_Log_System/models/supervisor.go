package models

type Supervisor struct {
	Id          int
	Name        string
	UserName    string
	Email       string
	Mobile      string
	DateOfBirth string
	Designation string
	Password    string
	UserType    int
	Status      int
}
